package finalAssesmentjava;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * The {@code Challenger_Login_Page} class creates a login window for players to access the game.
 * It allows players to enter their username and password and verifies them against a database.
 * If the credentials are correct, the player is granted access to the game menu.
 * It also provides a registration button to redirect to the registration page for new players.
 */
public class Challenger_Login_Page extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField usernameField;
    private JPasswordField passwordField;

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/player_registration";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    /**
     * Launch the application.
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Challenger_Login_Page frame = new Challenger_Login_Page();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame. Initializes the login window with its components.
     */
    public Challenger_Login_Page() {
        setTitle("Challenger Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 400, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(50, 50, 100, 25);
        contentPane.add(lblUsername);

        usernameField = new JTextField();
        usernameField.setBounds(160, 50, 150, 25);
        contentPane.add(usernameField);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(50, 90, 100, 25);
        contentPane.add(lblPassword);

        passwordField = new JPasswordField();
        passwordField.setBounds(160, 90, 150, 25);
        contentPane.add(passwordField);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(90, 180, 100, 30);
        contentPane.add(btnLogin);

        JButton btnRegister = new JButton("Register");
        btnRegister.setBounds(200, 180, 100, 30);
        contentPane.add(btnRegister);

        // Login button action
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        // Register button action
        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Challenger_Registration_Page registerPage = new Challenger_Registration_Page();
                registerPage.setVisible(true);
                dispose(); // Close the login page
            }
        });
    }

    /**
     * Method to handle login functionality.
     * Retrieves username and password from the input fields, connects to the database,
     * and verifies the credentials. On successful login opens the Game Menu.
     * Displays appropriate messages for success or failure.
     */
    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Debugging - Print the username and password (Consider removing in production)
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Query to verify username and password from the players table
            String query = "SELECT * FROM players WHERE username = ? AND password = ?";

            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);
                stmt.setString(2, password);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this, "Login Successful!");
                        // Pass the username to Game_Menu and open it
                        Game_Menu gameMenu = new Game_Menu(username);
                        gameMenu.setVisible(true);
                        dispose(); // Close the login page
                    } else {
                        JOptionPane.showMessageDialog(this, "Invalid Credentials!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Connection Error!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}