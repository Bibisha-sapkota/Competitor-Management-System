package finalAssesmentjava;



import javax.swing.*;

import finalAssesmentjava.Game_Menu;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;

public class QuizGame extends JFrame {
    private JLabel questionLabel;
    private JRadioButton optionA, optionB, optionC;
    private JButton nextButton;
    private ButtonGroup optionsGroup;

    private ArrayList<Question> questions;
    private int currentQuestionIndex = 0;
    private int score = 0;
    // Changed the maximum number of questions from 10 to 5
    private static final int MAX_QUESTIONS = 5;
    private String difficultyTable;
    private String username;
    private Game_Menu gameMenu; // Reference to Game_Menu

    public QuizGame(String username, Game_Menu gameMenu) {
        this.username = username;
        this.gameMenu = gameMenu;  // Store reference

        String[] difficulties = {"Easy", "Medium", "Hard"};
        String difficultyChoice = (String) JOptionPane.showInputDialog(
                null, "Select Difficulty:", "Difficulty Selection",
                JOptionPane.QUESTION_MESSAGE, null, difficulties, difficulties[0]);

        if (difficultyChoice == null) {
            JOptionPane.showMessageDialog(null, "No difficulty selected. Returning to menu...");
            gameMenu.setVisible(true);
            dispose();
            return;
        }

        difficultyTable = difficultyChoice.toLowerCase();
        setTitle("Quiz Game - " + username + " (" + difficultyChoice + " Mode)");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        questionLabel = new JLabel("Question will appear here");
        optionA = new JRadioButton();
        optionB = new JRadioButton();
        optionC = new JRadioButton();
        optionsGroup = new ButtonGroup();
        optionsGroup.add(optionA);
        optionsGroup.add(optionB);
        optionsGroup.add(optionC);

        nextButton = new JButton("Next Question");
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkAnswer();
                currentQuestionIndex++;
                if (currentQuestionIndex < questions.size()) {
                    displayQuestion();
                } else {
                    showFinalScore();
                }
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1));
        panel.add(questionLabel);
        panel.add(optionA);
        panel.add(optionB);
        panel.add(optionC);
        panel.add(nextButton);

        add(panel, BorderLayout.CENTER);

        loadQuestions();

        if (!questions.isEmpty()) {
            displayQuestion();
        } else {
            JOptionPane.showMessageDialog(this, "No questions found in " + difficultyChoice + " mode!", "Error", JOptionPane.ERROR_MESSAGE);
            gameMenu.setVisible(true);
            dispose();
        }

        setVisible(true);
    }

    private void loadQuestions() {
        questions = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/questions";
        String user = "root";
        String password = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + difficultyTable);

            while (rs.next()) {
                int id = rs.getInt("id");
                String question = rs.getString("question");
                String optA = rs.getString("option_a");
                String optB = rs.getString("option_b");
                String optC = rs.getString("option_c");
                String correctAns = rs.getString("answer");
                questions.add(new Question(id, question, optA, optB, optC, correctAns));
            }

            rs.close();
            stmt.close();
            conn.close();

            Collections.shuffle(questions);
            if (questions.size() > MAX_QUESTIONS) {
                questions = new ArrayList<>(questions.subList(0, MAX_QUESTIONS));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void displayQuestion() {
        Question q = questions.get(currentQuestionIndex);
        questionLabel.setText((currentQuestionIndex + 1) + ". " + q.getQuestion());
        optionA.setText(q.getOptionA());
        optionB.setText(q.getOptionB());
        optionC.setText(q.getOptionC());
        optionsGroup.clearSelection();
    }

    private void checkAnswer() {
        Question q = questions.get(currentQuestionIndex);
        String selectedAnswer = null;

        if (optionA.isSelected()) selectedAnswer = optionA.getText();
        if (optionB.isSelected()) selectedAnswer = optionB.getText();
        if (optionC.isSelected()) selectedAnswer = optionC.getText();

        if (selectedAnswer != null && selectedAnswer.equals(q.getCorrectAnswer())) {
            score++;
        }
    }

    private void showFinalScore() {
        JOptionPane.showMessageDialog(this, "Quiz Over!\nYour Score: " + score + " / " + MAX_QUESTIONS);
        saveResultToDatabase();
        gameMenu.setVisible(true); // Show the game menu again
        dispose(); // Close the quiz window
    }

    private void saveResultToDatabase() {
        String url = "jdbc:mysql://localhost:3306/questions";
        String user = "root";
        String password = "";

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            String query = "INSERT INTO quiz_results (username, difficulty, score) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);
            pstmt.setString(2, difficultyTable);
            pstmt.setInt(3, score);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new QuizGame("TestUser", new Game_Menu("TestUser"));
    }
}

class Question {
    private int id;
    private String question;
    private String optionA, optionB, optionC;
    private String correctAnswer;

    public Question(int id, String question, String optionA, String optionB, String optionC, String correctAnswer) {
        this.id = id;
        this.question = question;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestion() { return question; }
    public String getOptionA() { return optionA; }
    public String getOptionB() { return optionB; }
    public String getOptionC() { return optionC; }
    public String getCorrectAnswer() { return correctAnswer; }
}

