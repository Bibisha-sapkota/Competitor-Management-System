package finalAssesmentjava;



import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import finalAssesmentjava.QuizGame;

import java.awt.Color;

/**
 * The {@code Game_Menu} class represents the main game menu for the quiz application.
 * It allows the user to start a quiz, view player details, check the leaderboard,
 * and log out.
 */
public class Game_Menu extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private String username; // Store the username
    private JTable table;
    private DefaultTableModel tableModel;

    /**
     * Constructs the game menu frame with the given username.
     * 
     * @param username The username of the logged-in player.
     */
    public Game_Menu(String username) {
        this.username = username; // Store the passed username
        setTitle("Game Menu - " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 650, 401);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Welcome label using the stored username
        JLabel lblWelcome = new JLabel("Welcome, " + username + "!");
        lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblWelcome.setBounds(204, 10, 250, 35);
        contentPane.add(lblWelcome);

        // Buttons for the game menu
        JButton btnStartQuiz = new JButton("START QUIZZ");
        btnStartQuiz.setBounds(10, 79, 157, 59);
        contentPane.add(btnStartQuiz);

        JButton btnPlayerDetails = new JButton("PLAYER DETAILS");
        btnPlayerDetails.setBounds(10, 148, 157, 59);
        contentPane.add(btnPlayerDetails);

        JButton btnLeaderBoard = new JButton("LEADER BOARD");
        btnLeaderBoard.setBounds(10, 217, 157, 59);
        contentPane.add(btnLeaderBoard);

        // Log-out Button
        JButton btnLogOut = new JButton("LOG OUT");
        btnLogOut.setBackground(Color.RED);
        btnLogOut.setForeground(Color.WHITE);
        btnLogOut.setBounds(10, 319, 94, 35);
        contentPane.add(btnLogOut);

        // JTable setup with 3 columns (Username, Difficulty, Score)
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Username");
        tableModel.addColumn("Difficulty");
        tableModel.addColumn("Score");

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(200, 80, 400, 200);
        contentPane.add(scrollPane);

        // ActionListener for "START QUIZZ" button
        btnStartQuiz.addActionListener(e -> {
            setVisible(false); // Hide the game menu
            QuizGame quizGame = new QuizGame(username, Game_Menu.this);
            quizGame.setVisible(true);
        });

        // ActionListener for "PLAYER DETAILS" button
        btnPlayerDetails.addActionListener(e -> fetchPlayerDetails());

        // ActionListener for "LEADER BOARD" button
        btnLeaderBoard.addActionListener(e -> fetchLeaderBoard());

        // ActionListener for "LOG OUT" button
        btnLogOut.addActionListener(e -> {
            // Open the Mode_Page and close this window
            Mode_Page modePage = new Mode_Page();
            modePage.setVisible(true);
            dispose();
        });
    }

    /**
     * Fetches player details for the logged-in user from the database.
     */
    private void fetchPlayerDetails() {
        try {
            String url = "jdbc:mysql://localhost:3306/questions"; // Database name
            String user = "root"; 
            String password = ""; 

            Connection conn = DriverManager.getConnection(url, user, password);
            String query = "SELECT username, difficulty, score FROM quiz_results WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);

            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0);

            while (rs.next()) {
                String userName = rs.getString("username");
                String difficulty = rs.getString("difficulty");
                int score = rs.getInt("score");
                tableModel.addRow(new Object[]{userName, difficulty, score});
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Fetches leaderboard data from the database and displays it sorted by score in descending order.
     */
    private void fetchLeaderBoard() {
        try {
            String url = "jdbc:mysql://localhost:3306/questions"; // Database name
            String user = "root";
            String password = "";

            Connection conn = DriverManager.getConnection(url, user, password);
            String query = "SELECT username, difficulty, score FROM quiz_results ORDER BY score DESC";
            PreparedStatement stmt = conn.prepareStatement(query);

            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0);

            while (rs.next()) {
                String userName = rs.getString("username");
                String difficulty = rs.getString("difficulty");
                int score = rs.getInt("score");
                tableModel.addRow(new Object[]{userName, difficulty, score});
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Returns the username of the logged-in player.
     * 
     * @return the username
     */
    public String getUsername() {
        return username;
    }
}

