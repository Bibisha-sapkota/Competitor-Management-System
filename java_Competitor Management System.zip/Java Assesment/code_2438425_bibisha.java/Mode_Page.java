package finalAssesmentjava;



import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;

public class Mode_Page extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Mode_Page frame = new Mode_Page();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Mode_Page() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 427, 300);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.info);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("CHOOSE MODE:");
        lblNewLabel.setBackground(SystemColor.inactiveCaption);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel.setBounds(111, 20, 157, 32);
        contentPane.add(lblNewLabel);
        
        JButton btnChallenger = new JButton("CHALLEGERS");
        btnChallenger.setForeground(new Color(30, 144, 255));
        btnChallenger.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnChallenger.setBounds(219, 98, 157, 57);
        contentPane.add(btnChallenger);
        
        JButton btnAdmin = new JButton("ADMIN");
        btnAdmin.setForeground(new Color(255, 0, 0));
        btnAdmin.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAdmin.setBounds(33, 98, 157, 57);
        contentPane.add(btnAdmin);
        
        // ActionListener for the ADMIN button
        btnAdmin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Assuming Admin_Login_Page is a valid class in your project
                Admin_Login_Page adminLoginPage = new Admin_Login_Page();
                System.out.println("Clicked on admin mode");
                adminLoginPage.setVisible(true);
                dispose();  // Close the current Mode_Page frame
            }
        });
        
        // ActionListener for the CHALLENGERS button
        btnChallenger.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Assuming Challenger_Login_Page is a valid class in your project
                Challenger_Login_Page challengerLoginPage = new Challenger_Login_Page();
                System.out.println("Clicked on challenger mode");
                challengerLoginPage.setVisible(true);
                dispose();  // Close the current Mode_Page frame
            }
        });
    }
}
