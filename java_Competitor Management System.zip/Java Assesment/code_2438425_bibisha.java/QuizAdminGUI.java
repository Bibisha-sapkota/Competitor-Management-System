package finalAssesmentjava;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class QuizAdminGUI extends JFrame {

    // Input fields and controls
    private JTextField questionField;
    private JTextField optionAField;
    private JTextField optionBField;
    private JTextField optionCField;
    private JTextField answerField;
    private JTextField idField; // For update and delete
    private JComboBox<String> difficultyComboBox;

    // JTable and model for viewing questions
    private JTable questionTable;
    private DefaultTableModel tableModel;

    // Database connection details
    private String url = "jdbc:mysql://localhost:3306/questions"; // points to the 'questions' DB
    private String user = "root";       // your database user
    private String password = "";       // your database password

    public QuizAdminGUI() {
        // First, ensure that the database and required tables exist
        initializeDatabase();

        setTitle("Quiz Admin Panel");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout(10, 10));

        // -------------------- Input Panel --------------------
        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        inputPanel.add(new JLabel("Difficulty:"));
        difficultyComboBox = new JComboBox<>(new String[]{"easy", "medium", "hard"});
        inputPanel.add(difficultyComboBox);

        inputPanel.add(new JLabel("Question:"));
        questionField = new JTextField();
        inputPanel.add(questionField);

        inputPanel.add(new JLabel("Option A:"));
        optionAField = new JTextField();
        inputPanel.add(optionAField);

        inputPanel.add(new JLabel("Option B:"));
        optionBField = new JTextField();
        inputPanel.add(optionBField);

        inputPanel.add(new JLabel("Option C:"));
        optionCField = new JTextField();
        inputPanel.add(optionCField);

        inputPanel.add(new JLabel("Correct Answer (A, B, or C):"));
        answerField = new JTextField();
        inputPanel.add(answerField);

        inputPanel.add(new JLabel("ID (for Update/Delete):"));
        idField = new JTextField();
        inputPanel.add(idField);

        // -------------------- Button Panel --------------------
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton addButton = new JButton("Add Question");
        JButton updateButton = new JButton("Update Question");
        JButton deleteButton = new JButton("Delete Question");
        JButton viewButton = new JButton("View Questions");
        JButton viewReportButton = new JButton("View Report");
        JButton logoutButton = new JButton("LOG OUT"); // New Log-Out button
        logoutButton.setBackground(Color.RED);
        logoutButton.setForeground(Color.WHITE);

        addButton.addActionListener(e -> addQuestion());
        updateButton.addActionListener(e -> updateQuestion());
        deleteButton.addActionListener(e -> deleteQuestion());
        viewButton.addActionListener(e -> viewQuestions());
        viewReportButton.addActionListener(e -> viewReport());
        logoutButton.addActionListener(e -> {
            // When log-out is pressed, open Mode_Page and close this window
            Mode_Page modePage = new Mode_Page();
            modePage.setVisible(true);
            dispose();
        });

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(viewReportButton);
        buttonPanel.add(logoutButton);

        // -------------------- Top Panel: Input + Buttons --------------------
        JPanel northPanel = new JPanel();
        northPanel.setLayout(new BoxLayout(northPanel, BoxLayout.Y_AXIS));
        northPanel.add(inputPanel);
        northPanel.add(buttonPanel);
        getContentPane().add(northPanel, BorderLayout.NORTH);

        // -------------------- JTable Panel --------------------
        String[] columnNames = {"ID", "Question", "Option A", "Option B", "Option C", "Answer"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table cells non-editable
            }
        };
        questionTable = new JTable(tableModel);
        questionTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        // Set custom column widths
        questionTable.getColumnModel().getColumn(0).setPreferredWidth(50);   // ID
        questionTable.getColumnModel().getColumn(1).setPreferredWidth(300);  // Question
        questionTable.getColumnModel().getColumn(2).setPreferredWidth(150);  // Option A
        questionTable.getColumnModel().getColumn(3).setPreferredWidth(150);  // Option B
        questionTable.getColumnModel().getColumn(4).setPreferredWidth(150);  // Option C
        questionTable.getColumnModel().getColumn(5).setPreferredWidth(100);  // Answer

        JScrollPane tableScrollPane = new JScrollPane(questionTable);
        tableScrollPane.setPreferredSize(new Dimension(900, 400));
        getContentPane().add(tableScrollPane, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null); // Center on screen
        setVisible(true);
    }

    /**
     * Initializes the database and tables if they do not already exist.
     * Creates the tables for questions and the quiz_results table.
     */
    private void initializeDatabase() {
        // Create the database if it doesn't exist
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/", user, password);
             Statement statement = connection.createStatement()) {
            String createDatabaseSQL = "CREATE DATABASE IF NOT EXISTS questions";
            statement.executeUpdate(createDatabaseSQL);
            System.out.println("Database 'questions' is ensured.");
        } catch (SQLException ex) {
            System.err.println("Error creating database: " + ex.getMessage());
            ex.printStackTrace();
        }

        // Create the quiz question tables and the quiz_results table
        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement()) {

            // Create tables for questions based on difficulty
            String createEasyTable = "CREATE TABLE IF NOT EXISTS easy ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "question TEXT, "
                    + "option_a TEXT, "
                    + "option_b TEXT, "
                    + "option_c TEXT, "
                    + "answer VARCHAR(10)"
                    + ")";
            statement.executeUpdate(createEasyTable);

            String createMediumTable = "CREATE TABLE IF NOT EXISTS medium ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "question TEXT, "
                    + "option_a TEXT, "
                    + "option_b TEXT, "
                    + "option_c TEXT, "
                    + "answer VARCHAR(10)"
                    + ")";
            statement.executeUpdate(createMediumTable);

            String createHardTable = "CREATE TABLE IF NOT EXISTS hard ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "question TEXT, "
                    + "option_a TEXT, "
                    + "option_b TEXT, "
                    + "option_c TEXT, "
                    + "answer VARCHAR(10)"
                    + ")";
            statement.executeUpdate(createHardTable);

            // Create the quiz_results table for storing player results
            String createQuizResultsTable = "CREATE TABLE IF NOT EXISTS quiz_results ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "username VARCHAR(255), "
                    + "difficulty VARCHAR(50), "
                    + "score INT"
                    + ")";
            statement.executeUpdate(createQuizResultsTable);

            System.out.println("Tables 'easy', 'medium', 'hard', and 'quiz_results' are ensured.");
        } catch (SQLException ex) {
            System.err.println("Error creating tables: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // -------------------- CRUD Operations --------------------

    private void addQuestion() {
        String difficulty = (String) difficultyComboBox.getSelectedItem();
        String question = questionField.getText();
        String optionA = optionAField.getText();
        String optionB = optionBField.getText();
        String optionC = optionCField.getText();
        String answer = answerField.getText();

        try {
            addQuestionToDatabase(difficulty, question, optionA, optionB, optionC, answer);
            clearFields();
            JOptionPane.showMessageDialog(this, "Question added successfully!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error adding question: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void updateQuestion() {
        String difficulty = (String) difficultyComboBox.getSelectedItem();
        int id = Integer.parseInt(idField.getText());
        String question = questionField.getText();
        String optionA = optionAField.getText();
        String optionB = optionBField.getText();
        String optionC = optionCField.getText();
        String answer = answerField.getText();

        try {
            updateQuestionInDatabase(difficulty, id, question, optionA, optionB, optionC, answer);
            clearFields();
            JOptionPane.showMessageDialog(this, "Question updated successfully!");
        } catch (SQLException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error updating question: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void deleteQuestion() {
        String difficulty = (String) difficultyComboBox.getSelectedItem();
        int id = Integer.parseInt(idField.getText());

        try {
            deleteQuestionFromDatabase(difficulty, id);
            clearFields();
            JOptionPane.showMessageDialog(this, "Question deleted successfully!");
        } catch (SQLException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error deleting question: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * Retrieves and displays questions from the database for the selected difficulty.
     */
    private void viewQuestions() {
        String difficulty = (String) difficultyComboBox.getSelectedItem();
        String tableName = getTableName(difficulty);
        if (tableName == null) {
            JOptionPane.showMessageDialog(this,
                    "Invalid difficulty level!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        String sql = "SELECT * FROM " + tableName;
        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            // Clear existing rows in the table model
            tableModel.setRowCount(0);

            // Add each retrieved question to the table model
            while (rs.next()) {
                int id = rs.getInt("id");
                String question = rs.getString("question");
                String optionA = rs.getString("option_a");
                String optionB = rs.getString("option_b");
                String optionC = rs.getString("option_c");
                String answer = rs.getString("answer");
                Object[] row = {id, question, optionA, optionB, optionC, answer};
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error retrieving questions: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    /**
     * Retrieves and displays the leaderboard from the quiz_results table.
     * The report is sorted in descending order by score.
     */
    private void viewReport() {
        String sql = "SELECT * FROM quiz_results ORDER BY score DESC";
        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            // Create a table model for the report
            DefaultTableModel reportModel = new DefaultTableModel(new Object[]{"ID", "Username", "Difficulty", "Score"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Make cells non-editable
                }
            };

            // Add each record to the report model
            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String difficulty = rs.getString("difficulty");
                int score = rs.getInt("score");
                reportModel.addRow(new Object[]{id, username, difficulty, score});
            }

            // Create a JTable for the report
            JTable reportTable = new JTable(reportModel);
            reportTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
            JScrollPane scrollPane = new JScrollPane(reportTable);

            // Create a new JFrame to display the report
            JFrame reportFrame = new JFrame("Quiz Leaderboard Report");
            reportFrame.getContentPane().add(scrollPane);
            reportFrame.setSize(600, 400);
            reportFrame.setLocationRelativeTo(null);
            reportFrame.setVisible(true);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error retrieving report: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    // -------------------- Database Operations --------------------

    private void addQuestionToDatabase(String difficulty, String question, String optionA, String optionB,
                                         String optionC, String answer) throws SQLException {
        String tableName = getTableName(difficulty);
        if (tableName == null) {
            throw new IllegalArgumentException("Invalid difficulty level: " + difficulty);
        }
        String sql = "INSERT INTO " + tableName + " (question, option_a, option_b, option_c, answer) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, question);
            statement.setString(2, optionA);
            statement.setString(3, optionB);
            statement.setString(4, optionC);
            statement.setString(5, answer);
            statement.executeUpdate();
        }
    }

    private void updateQuestionInDatabase(String difficulty, int id, String question, String optionA,
                                            String optionB, String optionC, String answer) throws SQLException {
        String tableName = getTableName(difficulty);
        if (tableName == null) {
            throw new IllegalArgumentException("Invalid difficulty level: " + difficulty);
        }
        String sql = "UPDATE " + tableName + " SET question = ?, option_a = ?, option_b = ?, option_c = ?, answer = ? WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, question);
            statement.setString(2, optionA);
            statement.setString(3, optionB);
            statement.setString(4, optionC);
            statement.setString(5, answer);
            statement.setInt(6, id);
            statement.executeUpdate();
        }
    }

    private void deleteQuestionFromDatabase(String difficulty, int id) throws SQLException {
        String tableName = getTableName(difficulty);
        if (tableName == null) {
            throw new IllegalArgumentException("Invalid difficulty level: " + difficulty);
        }
        String sql = "DELETE FROM " + tableName + " WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    private String getTableName(String difficulty) {
        switch (difficulty.toLowerCase()) {
            case "easy":
                return "easy";
            case "medium":
                return "medium";
            case "hard":
                return "hard";
            default:
                return null;
        }
    }

    private void clearFields() {
        questionField.setText("");
        optionAField.setText("");
        optionBField.setText("");
        optionCField.setText("");
        answerField.setText("");
        idField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new QuizAdminGUI());
    }
}

