package finalAssesmentjava;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * This class creates a graphical user interface for adding questions to a quiz or assessment.
 * It allows users to input a question, provide four answer options, select the correct answer,
 * and specify the difficulty level.
 */
public class AddQuestionFrame extends JFrame {
    
    /** Dropdown menu for selecting the difficulty level */
    private JComboBox<String> levelComboBox;
    
    /** Text fields for entering the question and answer options */
    private JTextField questionField;
    /** Text fields for entering the question and answer options */
    private JTextField option1Field, option2Field, option3Field, option4Field;
    
    /** Radio buttons for selecting the correct answer */
    private JRadioButton option1Radio, option2Radio, option3Radio, option4Radio;
    
    /** A button group to ensure only one option is selected as the correct answer */
    private ButtonGroup correctOptionGroup;
    
    /** Button for saving the question */
    private JButton saveButton;

    /**
     * Constructor that initializes the GUI components and sets up the layout.
     */
    public AddQuestionFrame() {
        setTitle("Add Questions");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 645);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout(10, 10));

      
        JPanel levelPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        levelPanel.add(new JLabel("Select Difficulty Level:"));
        levelComboBox = new JComboBox<>(new String[] {"Beginner", "Mild", "Expert"});
        levelPanel.add(levelComboBox);
        getContentPane().add(levelPanel, BorderLayout.NORTH);

        // Main panel for question and options
        JPanel inputPanel = new JPanel();
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.setLayout(null);

        // Question field
        JLabel label = new JLabel("Question:");
        label.setBounds(10, 12, 228, 53);
        inputPanel.add(label);
        questionField = new JTextField();
        questionField.setBounds(248, 12, 228, 53);
        inputPanel.add(questionField);

        // Option 1 field
        JLabel label_1 = new JLabel("Option 1:");
        label_1.setBounds(10, 75, 228, 53);
        inputPanel.add(label_1);
        option1Field = new JTextField();
        option1Field.setBounds(248, 75, 228, 53);
        inputPanel.add(option1Field);

        // Option 2 field
        JLabel label_2 = new JLabel("Option 2:");
        label_2.setBounds(10, 138, 228, 53);
        inputPanel.add(label_2);
        option2Field = new JTextField();
        option2Field.setBounds(248, 138, 228, 53);
        inputPanel.add(option2Field);

        // Option 3 field
        JLabel label_3 = new JLabel("Option 3:");
        label_3.setBounds(10, 201, 228, 53);
        inputPanel.add(label_3);
        option3Field = new JTextField();
        option3Field.setBounds(248, 201, 228, 53);
        inputPanel.add(option3Field);

        // Option 4 field
        JLabel label_4 = new JLabel("Option 4:");
        label_4.setBounds(10, 264, 228, 53);
        inputPanel.add(label_4);
        option4Field = new JTextField();
        option4Field.setBounds(248, 264, 228, 53);
        inputPanel.add(option4Field);

        // Panel for selecting the correct option
        JLabel label_5 = new JLabel("Select Correct Option:");
        label_5.setBounds(10, 327, 228, 53);
        inputPanel.add(label_5);
        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        radioPanel.setBounds(248, 327, 228, 53);
        option1Radio = new JRadioButton("1");
        option2Radio = new JRadioButton("2");
        option3Radio = new JRadioButton("3");
        option4Radio = new JRadioButton("4");
        correctOptionGroup = new ButtonGroup();
        correctOptionGroup.add(option1Radio);
        correctOptionGroup.add(option2Radio);
        correctOptionGroup.add(option3Radio);
        correctOptionGroup.add(option4Radio);
        radioPanel.add(option1Radio);
        radioPanel.add(option2Radio);
        radioPanel.add(option3Radio);
        radioPanel.add(option4Radio);
        inputPanel.add(radioPanel);

        getContentPane().add(inputPanel, BorderLayout.CENTER);

        // Save Button at the bottom
        saveButton = new JButton("Save Question");
        getContentPane().add(saveButton, BorderLayout.SOUTH);

        // Action Listener for the Save button
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveQuestion();
            }
        });
    }

    /**
     * Validates the input fields and displays a confirmation message.
     * In a real implementation, this method would save the question to a database.
     */
    private void saveQuestion() {
        String level = (String) levelComboBox.getSelectedItem();
        String question = questionField.getText().trim();
        String option1 = option1Field.getText().trim();
        String option2 = option2Field.getText().trim();
        String option3 = option3Field.getText().trim();
        String option4 = option4Field.getText().trim();

        int correctOption = 0;
        if (option1Radio.isSelected()) correctOption = 1;
        else if (option2Radio.isSelected()) correctOption = 2;
        else if (option3Radio.isSelected()) correctOption = 3;
        else if (option4Radio.isSelected()) correctOption = 4;

        // Validate inputs
        if (question.isEmpty() || option1.isEmpty() || option2.isEmpty() ||
            option3.isEmpty() || option4.isEmpty() || correctOption == 0) {
            JOptionPane.showMessageDialog(this,
                    "Please fill all fields and select the correct option.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Question Added:\n" +
                "Level: " + level + "\n" +
                "Question: " + question + "\n" +
                "Options: [1] " + option1 + ", [2] " + option2 +
                ", [3] " + option3 + ", [4] " + option4 +
                "\nCorrect Option: " + correctOption,
                "Success", JOptionPane.INFORMATION_MESSAGE);

        // Clear fields for the next question
        questionField.setText("");
        option1Field.setText("");
        option2Field.setText("");
        option3Field.setText("");
        option4Field.setText("");
        correctOptionGroup.clearSelection();
    }

    /**
     * The main method serves as the entry point for the application.
     * It initializes and displays the AddQuestionFrame GUI using SwingUtilities 
     * to ensure that the GUI is created on the Event Dispatch Thread (EDT).
     *
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AddQuestionFrame().setVisible(true);
        });
    }
}