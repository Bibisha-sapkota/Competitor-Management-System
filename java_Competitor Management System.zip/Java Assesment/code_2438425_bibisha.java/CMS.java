package finalAssesmentjava;



import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;

/**
 * A GUI-based Competitor Management System application.
 * 
 * <p>
 * The available operations are:
 * <ul>
 *   <li>1. Generate Full Report</li>
 *   <li>2. Display Top Performer</li>
 *   <li>3. Generate Statistics</li>
 *   <li>4. Exit</li>
 * </ul>
 * 
 * 
 * 
 * @author bibisha sapkota
 *         
 */
public class CMS extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTable table;

    /**
     * The main entry point for the Competitor Management System application.
     *
     * @param args the command-line arguments (not used)
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CMS frame = new CMS();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Constructs the main frame for the Competitor Management System.
     * 
     * <p>
     * Initializes the GUI components including labels, a text field for user input,
     * and a table to display results. 
     * </p>
     */
    public CMS() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 961, 633);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblTitle = new JLabel("COMPETITOR MANAGEMENT SYSTEM");
        lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblTitle.setBounds(246, 10, 333, 46);
        contentPane.add(lblTitle);
        
        JLabel lblFullReport = new JLabel("1. GENERATE FULL REPORT");
        lblFullReport.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblFullReport.setBounds(10, 83, 256, 46);
        contentPane.add(lblFullReport);
        
        JLabel lblTopPerformer = new JLabel("2. DISPLAY TOP PERFORMER");
        lblTopPerformer.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblTopPerformer.setBounds(10, 153, 262, 46);
        contentPane.add(lblTopPerformer);
        
        JLabel lblStatistics = new JLabel("3. GENERATE STATISTICS");
        lblStatistics.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblStatistics.setBounds(10, 220, 256, 46);
        contentPane.add(lblStatistics);
        
        JLabel lblExit = new JLabel("4. EXIT");
        lblExit.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblExit.setBounds(10, 276, 77, 46);
        contentPane.add(lblExit);
        
        textField = new JTextField();
        textField.setBounds(178, 345, 77, 26);
        contentPane.add(textField);
        textField.setColumns(10);
        
        JLabel lblChoice = new JLabel("ENTER YOUR CHOICE :");
        lblChoice.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblChoice.setBounds(10, 332, 158, 46);
        contentPane.add(lblChoice);
        
        table = new JTable();
        table.setBounds(298, 83, 639, 503);
        contentPane.add(table);
        
        System.out.println("Competitor Management System\n"
                + "1.Generate Full Report\n"
                + "2.Display Top Performer\n"
                + "3.Generate Statistics\n"
                + "4.Exit\n");
       
        textField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String choice = textField.getText().trim();
                // Display the selected choice in the console
                System.out.println("Choice selected: " + choice);
                
                if (choice.equals("1")) {
                    generateFullReport();
                } else if (choice.equals("2")) {
                    displayTopPerformer();
                } else if (choice.equals("3")) {
                    displayStatistics();
                } else if (choice.equals("4")) {
                    System.exit(0);
                }
            }
        });
    }
    
    /**
     * Generates a full report of quiz results.
     * 
     * <p>
     *, adds additional rows for the highest, lowest, and average scores.
     * The complete data is then displayed in the table.
     * </p>
     */
    private void generateFullReport() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Username");
        model.addColumn("Difficulty");
        model.addColumn("Score");
        
        String dbUrl = "jdbc:mysql://localhost:3306/questions";
        String dbUser = "root";
        String dbPassword = "";
        
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM quiz_results");
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String difficulty = rs.getString("difficulty");
                int score = rs.getInt("score");
                model.addRow(new Object[]{id, username, difficulty, score});
            }
            
            PreparedStatement psHighest = conn.prepareStatement("SELECT * FROM quiz_results ORDER BY score DESC LIMIT 1");
            PreparedStatement psLowest = conn.prepareStatement("SELECT * FROM quiz_results ORDER BY score ASC LIMIT 1");
            PreparedStatement psAvg = conn.prepareStatement("SELECT AVG(score) AS avgScore FROM quiz_results");
            
            ResultSet rsHighest = psHighest.executeQuery();
            ResultSet rsLowest = psLowest.executeQuery();
            ResultSet rsAvg = psAvg.executeQuery();
            
            if (rsHighest.next())
                model.addRow(new Object[]{"Highest", rsHighest.getInt("id"), rsHighest.getString("username"), rsHighest.getString("difficulty"), rsHighest.getInt("score")});
            
            if (rsLowest.next())
                model.addRow(new Object[]{"Lowest", rsLowest.getInt("id"), rsLowest.getString("username"), rsLowest.getString("difficulty"), rsLowest.getInt("score")});
            
            if (rsAvg.next())
                model.addRow(new Object[]{"Average", "", "", "", rsAvg.getDouble("avgScore")});
            
            table.setModel(model);
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * Displays the top performer(s) in the quiz results.
     * 
     */
    private void displayTopPerformer() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Username");
        model.addColumn("Difficulty");
        model.addColumn("Score");
        
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM quiz_results ORDER BY score DESC");
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("id"), rs.getString("username"), rs.getString("difficulty"), rs.getInt("score")});
            }
            table.setModel(model);
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * Displays statistics for the quiz results.
     * 
     * <p>
     * Retrieves and displays the highest score, lowest score, and average score from the database.
     * The results are shown in the table with an additional column to indicate the category.
     * </p>
     */
    private void displayStatistics() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Category");
        model.addColumn("ID");
        model.addColumn("Username");
        model.addColumn("Difficulty");
        model.addColumn("Score");
        
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
             PreparedStatement psHighest = conn.prepareStatement("SELECT * FROM quiz_results ORDER BY score DESC LIMIT 1");
             PreparedStatement psLowest = conn.prepareStatement("SELECT * FROM quiz_results ORDER BY score ASC LIMIT 1");
             PreparedStatement psAvg = conn.prepareStatement("SELECT AVG(score) AS avgScore FROM quiz_results");
             ResultSet rsHighest = psHighest.executeQuery();
             ResultSet rsLowest = psLowest.executeQuery();
             ResultSet rsAvg = psAvg.executeQuery()) {
            
            if (rsHighest.next())
                model.addRow(new Object[]{"Highest", rsHighest.getInt("id"), rsHighest.getString("username"), rsHighest.getString("difficulty"), rsHighest.getInt("score")});
            
            if (rsLowest.next())
                model.addRow(new Object[]{"Lowest", rsLowest.getInt("id"), rsLowest.getString("username"), rsLowest.getString("difficulty"), rsLowest.getInt("score")});
            
            if (rsAvg.next())
                model.addRow(new Object[]{"Average", "", "", "", rsAvg.getDouble("avgScore")});
            
            table.setModel(model);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
