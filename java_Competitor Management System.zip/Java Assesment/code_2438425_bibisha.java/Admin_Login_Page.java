package finalAssesmentjava;



import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * The {@code Admin_Login_Page} class represents a graphical user interface (GUI) 
 * for the administrator login page.
 * It provides text fields for username and password input, and buttons for login and navigation.
 * The login system verifies admin credentials from a MySQL database.
 * 
 * This class extends {@link JFrame} and sets up the login form layout.
 */
public class Admin_Login_Page extends JFrame {
    
    /** Ensures serialization compatibility **/
    private static final long serialVersionUID = 1L;
    
    /** Main panel for the login page **/
    private JPanel contentPane; 
    
    /** Field for entering the username **/
    private JTextField textField; 
    
    /** Field for entering the password **/
    private JPasswordField passwordField;

    /**
     * The main method serves as the entry point for the application.
     * It initializes and displays the {@code Admin_Login_Page} GUI on the Event Dispatch Thread (EDT).
     *
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Admin_Login_Page frame = new Admin_Login_Page();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Constructs the Admin Login Page GUI.
     * Initializes the components and adds action listeners for login and navigation buttons.
     */
    public Admin_Login_Page() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.info);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Admin Login Page");
        lblNewLabel.setFont(new Font("Verdana", Font.PLAIN, 20));
        lblNewLabel.setBounds(100, 10, 204, 27);
        contentPane.add(lblNewLabel);

        JLabel lblUsername = new JLabel("Username :");
        lblUsername.setFont(new Font("Verdana", Font.PLAIN, 15));
        lblUsername.setBounds(54, 81, 92, 27);
        contentPane.add(lblUsername);

        JLabel lblPassword = new JLabel("Password :");
        lblPassword.setFont(new Font("Verdana", Font.PLAIN, 15));
        lblPassword.setBounds(54, 128, 92, 27);
        contentPane.add(lblPassword);

        textField = new JTextField();
        textField.setBounds(169, 87, 192, 19);
        contentPane.add(textField);
        textField.setColumns(10);

        passwordField = new JPasswordField();
        passwordField.setBounds(169, 134, 192, 19);
        contentPane.add(passwordField);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(219, 175, 85, 21);
        contentPane.add(btnLogin);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(119, 175, 85, 21);
        contentPane.add(btnBack);

        // Login button action listener
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = textField.getText();
                String password = new String(passwordField.getPassword());

                if (authenticateAdmin(username, password)) {
                    JOptionPane.showMessageDialog(null, "Login Successful!");
                    System.out.println("Login successful");
                    dispose(); // Close login page
                    openAdminPage(); // Open Admin Page
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Credentials!");
                    System.out.println("Login unsuccessful");
                }
            }
        });

        // Back button action listener
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close login page
                openModePage(); // Open Mode Page
            }
        });
    }

    /**
     * Authenticates the admin user by verifying the provided username and password 
     * against the database.
     * 
     * @param username The username entered by the admin.
     * @param password The password entered by the admin.
     * @return {@code true} if the credentials are valid; {@code false} otherwise.
     */
    private boolean authenticateAdmin(String username, String password) {
        String url = "jdbc:mysql://localhost:3306/AdminDB";
        String dbUser = "root";
        String dbPass = "";

        try (Connection conn = DriverManager.getConnection(url, dbUser, dbPass)) {
            String query = "SELECT password FROM Admins WHERE username=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");
                return storedPassword.equals(password);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    /**
     * Opens the Admin Page upon successful login.
     */
    private void openAdminPage() {
        QuizAdminGUI adminPage = new QuizAdminGUI();
        adminPage.setVisible(true);
    }

    /**
     * Opens the Mode Selection Page.
     */
    private void openModePage() {
        Mode_Page modePage = new Mode_Page();
        modePage.setVisible(true);
    }
}
