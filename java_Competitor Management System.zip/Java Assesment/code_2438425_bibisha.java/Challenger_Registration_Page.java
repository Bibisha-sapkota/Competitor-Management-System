package finalAssesmentjava;



import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * The {@code Challenger_Registration_Page} class provides a user interface for registering new players.
 * It allows users to enter a username and password, which are then stored in a database.
 * This page also includes validation to ensure that all fields are filled and that the chosen
 * username is unique. Upon successful registration, the user is redirected to the login page.
 */
public class Challenger_Registration_Page extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField usernameField;
    private JTextField passwordField;

    // Database credentials
    private final String DB_URL = "jdbc:mysql://localhost:3306/player_registration";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = ""; // Default XAMPP password is empty

    /**
     * Launch the application.
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Challenger_Registration_Page frame = new Challenger_Registration_Page();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame. Initializes the registration window with its components.
     */
    public Challenger_Registration_Page() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 545, 350); // Adjusted window size
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel playerRegisterTitle = new JLabel("Registration");
        playerRegisterTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));
        playerRegisterTitle.setBounds(180, 10, 150, 30);
        contentPane.add(playerRegisterTitle);

        JLabel playerRegisterUsername = new JLabel("Username:");
        playerRegisterUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
        playerRegisterUsername.setBounds(50, 80, 100, 30);
        contentPane.add(playerRegisterUsername);

        JLabel playerRegisterPassword = new JLabel("Password:");
        playerRegisterPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
        playerRegisterPassword.setBounds(50, 130, 100, 30);
        contentPane.add(playerRegisterPassword);

        usernameField = new JTextField();
        usernameField.setBounds(180, 80, 250, 30);
        contentPane.add(usernameField);

        passwordField = new JTextField();
        passwordField.setBounds(180, 130, 250, 30);
        contentPane.add(passwordField);

        JButton registerButton = new JButton("Sign-up");
        registerButton.setBackground(new Color(0, 128, 0));
        registerButton.setBounds(200, 200, 120, 35); // Adjusted button position
        contentPane.add(registerButton);

        registerButton.addActionListener(e -> registerUser());
    }

    /**
     * Handles the user registration process. Retrieves the entered username and password,
     * validates the input, checks for duplicate usernames, and inserts the new user data
     * into the database.  Displays appropriate messages for success or failure.
     */
    private void registerUser() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(contentPane, "Please fill all fields.");
            return;
        }

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Check if username already exists
            String checkQuery = "SELECT COUNT(*) FROM players WHERE username = ?";
            PreparedStatement checkPst = con.prepareStatement(checkQuery);
            checkPst.setString(1, username);
            ResultSet rs = checkPst.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(contentPane, "Username already used. Choose another.");
                return;
            }

            // Insert new user
            String query = "INSERT INTO players (username, password) VALUES (?, ?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                JOptionPane.showMessageDialog(contentPane, "Registration successful!");
                Challenger_Login_Page loginPage = new Challenger_Login_Page();
                loginPage.setVisible(true);
                dispose();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(contentPane, "Registration failed: " + ex.getMessage());
        }
    }
}
