package finalAssesmentjava;


import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The {@code Admin_Page} class represents the main interface for the admin panel.
 * It allows administrators to add, delete, update questions, view reports, and log out.
 * This class extends {@link JFrame} and provides a graphical user interface (GUI).
 */
public class Admin_Page extends JFrame {

    /** Ensures serialization compatibility */
    private static final long serialVersionUID = 1L;

    /** The main panel for the Admin Page */
    private JPanel contentPane;

    /** A table to display data (e.g., reports or questions) */
    private JTable table;

    /**
     * The main method serves as the entry point for the application.
     * It initializes and displays the {@code Admin_Page} GUI on the Event Dispatch Thread (EDT).
     *
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Admin_Page frame = new Admin_Page();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Constructs the Admin Page frame.
     * Initializes components and sets up the GUI layout.
     */
    public Admin_Page() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 718, 637);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title Label
        JLabel tittle = new JLabel("ADMIN PANEL");
        tittle.setFont(new Font("Tahoma", Font.BOLD, 20));
        tittle.setBounds(265, 22, 149, 44);
        contentPane.add(tittle);

        // Buttons for admin actions
        JButton add_questions = new JButton("ADD QUESTIONS");
        add_questions.setBounds(10, 71, 184, 96);
        contentPane.add(add_questions);

        JButton delete_questions = new JButton("DELETE QUESTIONS");
        delete_questions.setBounds(10, 177, 184, 96);
        contentPane.add(delete_questions);

        JButton update_questions = new JButton("UPDATE QUESTIONS");
        update_questions.setBounds(10, 283, 184, 96);
        contentPane.add(update_questions);

        JButton view_reports = new JButton("VIEW REPORTS");
        view_reports.setBounds(10, 388, 184, 96);
        contentPane.add(view_reports);

        // Logout Button
        JButton btnNewButton = new JButton("LOG-OUT");
        btnNewButton.setForeground(Color.WHITE);
        btnNewButton.setBackground(new Color(204, 0, 0));
        btnNewButton.setBounds(32, 565, 118, 25);
        contentPane.add(btnNewButton);
        
        // Table for displaying data
        table = new JTable();
        table.setBounds(249, 82, 412, 400);
        contentPane.add(table);

        /**
         * Action Listener for the "Add Questions" button.
         * Opens the {@link AddQuestionFrame} window.
         */
        add_questions.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddQuestionFrame().setVisible(true);
            }
        });
    }
}

